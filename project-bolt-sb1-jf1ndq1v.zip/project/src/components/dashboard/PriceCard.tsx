import { TrendingUp, TrendingDown } from 'lucide-react';
import { Card } from '../ui/Card';
import { formatCurrency, formatPercentage } from '../../utils/formatters';

interface PriceCardProps {
  name: string;
  price: number;
  change: number;
}

export function PriceCard({ name, price, change }: PriceCardProps) {
  const isPositive = change >= 0;
  const Icon = isPositive ? TrendingUp : TrendingDown;

  return (
    <Card>
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{name}</h3>
          <p className="text-2xl font-bold mt-1">{formatCurrency(price)}</p>
        </div>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          <Icon className="h-5 w-5" />
          <span className="ml-1 font-medium">{formatPercentage(change)}</span>
        </div>
      </div>
    </Card>
  );
}