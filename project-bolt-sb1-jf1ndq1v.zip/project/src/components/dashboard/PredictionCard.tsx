import { TrendingUp, TrendingDown } from 'lucide-react';

interface PredictionCardProps {
  crypto: string;
  currentPrice: number;
  predictedPrice: number;
  change: number;
}

export function PredictionCard({ crypto, currentPrice, predictedPrice, change }: PredictionCardProps) {
  const isPositive = change >= 0;

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex justify-between items-start">
        <div>
          <h3 className="text-lg font-semibold text-gray-900">{crypto}</h3>
          <p className="text-sm text-gray-500">Current Price</p>
          <p className="text-2xl font-bold">${currentPrice.toLocaleString()}</p>
        </div>
        <div className={`flex items-center ${isPositive ? 'text-green-500' : 'text-red-500'}`}>
          {isPositive ? <TrendingUp className="h-5 w-5" /> : <TrendingDown className="h-5 w-5" />}
          <span className="ml-1 font-medium">{change}%</span>
        </div>
      </div>
      <div className="mt-4">
        <p className="text-sm text-gray-500">Predicted Price</p>
        <p className="text-xl font-semibold">${predictedPrice.toLocaleString()}</p>
      </div>
    </div>
  );
}