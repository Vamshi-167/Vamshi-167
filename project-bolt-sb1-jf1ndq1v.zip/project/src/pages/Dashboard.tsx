import { MainLayout } from '../components/layout/MainLayout';
import { PageHeader } from '../components/ui/PageHeader';
import { PriceCard } from '../components/dashboard/PriceCard';
import { Chart } from '../components/dashboard/Chart';

const prices = [
  { name: 'Bitcoin', price: 45000, change: 5.67 },
  { name: 'Ethereum', price: 2800, change: 3.21 },
  { name: 'Cardano', price: 1.2, change: -2.34 },
];

export function Dashboard() {
  return (
    <MainLayout>
      <PageHeader title="Dashboard" />
      
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        {prices.map((price) => (
          <PriceCard key={price.name} {...price} />
        ))}
      </div>

      <Chart />
    </MainLayout>
  );
}