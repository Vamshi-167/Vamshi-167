import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from 'recharts';
import { Card } from '../ui/Card';

const data = [
  { date: 'Jan', price: 42000 },
  { date: 'Feb', price: 45000 },
  { date: 'Mar', price: 48000 },
  { date: 'Apr', price: 44000 },
  { date: 'May', price: 46000 },
];

export function Chart() {
  return (
    <Card className="h-[400px]">
      <h2 className="text-xl font-semibold mb-4">Price History</h2>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <CartesianGrid strokeDasharray="3 3" />
          <XAxis dataKey="date" />
          <YAxis />
          <Tooltip />
          <Line 
            type="monotone" 
            dataKey="price" 
            stroke="#2563eb" 
            strokeWidth={2}
            dot={false}
          />
        </LineChart>
      </ResponsiveContainer>
    </Card>
  );
}